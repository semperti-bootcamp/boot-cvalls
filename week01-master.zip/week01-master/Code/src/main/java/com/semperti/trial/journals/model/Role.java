package com.semperti.trial.journals.model;

public enum Role {
	USER, PUBLISHER
}